package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller  // Dies ist der Spring Controller
@RequestMapping(path="/demo")  // Der Basis-URL-Pfad
public class MainController {

	@Autowired  // Das Repository für den Zugriff auf die Daten
	private WarehouseRepository warehouseRepository;

	// Endpunkt, um alle Warehouses mit deren Produkten anzuzeigen
	@GetMapping(path="/all")
	public @ResponseBody Iterable<Warehouse> getAllWarehouses() {
		// Rückgabe aller Warehouse-Daten aus der Datenbank
		return warehouseRepository.findAll();
	}
}
