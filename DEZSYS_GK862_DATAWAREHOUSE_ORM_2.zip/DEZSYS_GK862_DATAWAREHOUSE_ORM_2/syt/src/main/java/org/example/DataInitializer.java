package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private WarehouseRepository warehouseRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void run(String... args) throws Exception {
        // Erstelle 2 Warehouse-Datensätze
        Warehouse warehouse1 = new Warehouse();
        warehouse1.setWarehouseID("003");
        warehouse1.setWarehouseName("Graz Zentrallager");
        warehouse1.setWarehouseAddress("Lagerstraße 12");
        warehouse1.setWarehousePostalCode("8010");
        warehouse1.setWarehouseCity("Graz");
        warehouse1.setWarehouseCountry("Austria");
        warehouse1.setTimestamp("2022-05-10 10:30:45.123");

        Warehouse warehouse2 = new Warehouse();
        warehouse2.setWarehouseID("004");
        warehouse2.setWarehouseName("Salzburg Logistikzentrum");
        warehouse2.setWarehouseAddress("Hauptstraße 99");
        warehouse2.setWarehousePostalCode("5020");
        warehouse2.setWarehouseCity("Salzburg");
        warehouse2.setWarehouseCountry("Austria");
        warehouse2.setTimestamp("2022-05-11 11:15:30.789");

        warehouseRepository.save(warehouse1);
        warehouseRepository.save(warehouse2);

        // Erstelle 10 Product-Datensätze
        Product product1 = new Product();
        product1.setProductID("00-123456");
        product1.setProductName("Bio Tomatensaft");
        product1.setProductCategory("Getränk");
        product1.setProductQuantity(2000);
        product1.setProductUnit("Flasche 1L");
        product1.setWarehouse(warehouse1);

        Product product2 = new Product();
        product2.setProductID("00-654321");
        product2.setProductName("Mandelmilch");
        product2.setProductCategory("Getränk");
        product2.setProductQuantity(1800);
        product2.setProductUnit("Packung 1L");
        product2.setWarehouse(warehouse1);

        Product product3 = new Product();
        product3.setProductID("00-789012");
        product3.setProductName("Dinkelbrot");
        product3.setProductCategory("Lebensmittel");
        product3.setProductQuantity(2500);
        product3.setProductUnit("Stück");
        product3.setWarehouse(warehouse1);

        Product product4 = new Product();
        product4.setProductID("00-345678");
        product4.setProductName("Honig Bio");
        product4.setProductCategory("Lebensmittel");
        product4.setProductQuantity(1300);
        product4.setProductUnit("Glas 500g");
        product4.setWarehouse(warehouse1);

        Product product5 = new Product();
        product5.setProductID("00-901234");
        product5.setProductName("Bio Reis");
        product5.setProductCategory("Lebensmittel");
        product5.setProductQuantity(2700);
        product5.setProductUnit("Packung 1kg");
        product5.setWarehouse(warehouse2);

        Product product6 = new Product();
        product6.setProductID("00-567890");
        product6.setProductName("Cashewkerne");
        product6.setProductCategory("Snacks");
        product6.setProductQuantity(1500);
        product6.setProductUnit("Packung 250g");
        product6.setWarehouse(warehouse2);

        Product product7 = new Product();
        product7.setProductID("00-112233");
        product7.setProductName("Haferflocken");
        product7.setProductCategory("Lebensmittel");
        product7.setProductQuantity(3200);
        product7.setProductUnit("Packung 500g");
        product7.setWarehouse(warehouse2);

        Product product8 = new Product();
        product8.setProductID("00-445566");
        product8.setProductName("Dunkle Schokolade");
        product8.setProductCategory("Süßigkeiten");
        product8.setProductQuantity(900);
        product8.setProductUnit("Tafel 100g");
        product8.setWarehouse(warehouse2);

        Product product9 = new Product();
        product9.setProductID("00-778899");
        product9.setProductName("Erdnussbutter");
        product9.setProductCategory("Lebensmittel");
        product9.setProductQuantity(1100);
        product9.setProductUnit("Glas 500g");
        product9.setWarehouse(warehouse2);

        Product product10 = new Product();
        product10.setProductID("00-334455");
        product10.setProductName("Studentenfutter");
        product10.setProductCategory("Snacks");
        product10.setProductQuantity(1400);
        product10.setProductUnit("Packung 200g");
        product10.setWarehouse(warehouse2);

        // Speichern der Produkte
        productRepository.save(product1);
        productRepository.save(product2);
        productRepository.save(product3);
        productRepository.save(product4);
        productRepository.save(product5);
        productRepository.save(product6);
        productRepository.save(product7);
        productRepository.save(product8);
        productRepository.save(product9);
        productRepository.save(product10);
    }
}
